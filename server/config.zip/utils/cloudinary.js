const cloudinary = require("cloudinary").v2;
cloudinary.config({
  cloud_name: 'dxrmxvmkg',
  api_key: '656487527413962',
  api_secret: 'z-T5bs_VDWIIKbRW4FCTKT2c1q0',
}); 
module.exports = cloudinary;
